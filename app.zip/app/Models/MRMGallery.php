<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MRMGallery extends Model
{
    use HasFactory;
    protected $table = 'm_r_m_galleries';
}
