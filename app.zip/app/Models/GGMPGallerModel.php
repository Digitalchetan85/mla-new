<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GGMPGallerModel extends Model
{
    use HasFactory;

    protected $table = "g_g_m_p_galler_models"; 
}