<?php

namespace App\Http\Livewire\Constituency;

use Livewire\Component;

class WelfairActivities extends Component
{
    public function render()
    {
        return view('livewire.constituency.welfair-activities')->layout('layouts.page');
    }
}
