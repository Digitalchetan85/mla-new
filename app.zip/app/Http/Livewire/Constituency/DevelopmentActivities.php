<?php

namespace App\Http\Livewire\Constituency;

use Livewire\Component;

class DevelopmentActivities extends Component
{
    public function render()
    {
        return view('livewire.constituency.development-activities')->layout('layouts.page');
    }
}
