<!DOCTYPE html>
<html>

<head>
    <title>Register</title>
</head>

<body>

    <table rules="all" style="border-style: solid; border-color: #666;" cellpadding="10">
        
        <tbody>
            <tr>
                <th>Name</th>
                <td><?php echo e($data['name']); ?></td>
            </tr>
            <tr>
                <th>Eamil</th>
                <td><?php echo e($data['email']); ?></td>
            </tr>
            <tr>
                <th>Contact</th>
                <td><?php echo e($data['contact']); ?></td>
            </tr>
            <tr>
                <th>Mandal</th>
                <td><?php echo e($data['mandal']); ?></td>
            </tr>
            <tr>
                <th>Village</th>
                <td><?php echo e($data['village']); ?></td>
            </tr>
            <tr>
                <th>Address</th>
                <td><?php echo e($data['message']); ?></td>
            </tr>
        </tbody>
    </table>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\mla-new\resources\views/email/contactmail.blade.php ENDPATH**/ ?>