<div class="my-5">
    <style>
        nav {
            text-align: center;
        }

        nav svg {
            height: 10px;
        }

        nav .hidden {
            display: block !important;
        }

        .select-none {
            margin-right: 5px !important;
        }

    </style>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="">
                                    <h3>Registered Users</h3>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="text-end">
                                    <a href="<?php echo e(route('admin.export')); ?>" class="btn btn-primary" target="_blank">Export Data</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(Session::has('success')): ?>
                        <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <!-- Table -->
                        <div class="table-responsive">
                            <table class="table table-bordered align-middle text-center">
                                <thead>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Contact</th>
                                    <th>Mandal</th>
                                    <th>Village</th>
                                    <th>Address</th>
                                    <th>SSC Pass</th>
                                    <th>SSC Percentage</th>
                                    <th>Inter Pass</th>
                                    <th>Inter Percentage</th>
                                    <th>Qualification</th>
                                    <th>Graduation Stream</th>
                                    <th>Graduation Pass</th>
                                    <th>Graduation Percentage</th>
                                    <th>PG Pass</th>
                                    <th>PG Percentage</th>
                                    <th>Training</th>
                                    <th>Resume</th>
                                    
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->contact); ?></td>
                                        <td><?php echo e($user->mandal); ?></td>
                                        <td><?php echo e($user->village); ?></td>
                                        <td><?php echo e($user->address); ?></td>
                                        <td><?php echo e($user->sscyearofpass); ?></td>
                                        <td><?php echo e($user->sscpercentage); ?></td>
                                        <td><?php echo e($user->interyearofpass); ?></td>
                                        <td><?php echo e($user->interpercentage); ?></td>
                                        <td><?php echo e($user->qualification); ?></td>
                                        <td><?php echo e($user->graduationstream); ?></td>
                                        <td><?php echo e($user->graduationyearofpass); ?></td>
                                        <td><?php echo e($user->graduationpercentage); ?></td>
                                        <td><?php echo e($user->postgraduationyearofpass); ?></td>
                                        <td><?php echo e($user->postgraduationpercentage); ?></td>
                                        <td><?php echo e($user->trainings); ?></td>
                                        <td><a href="<?php echo e(asset('assets/images/resumes')); ?>/<?php echo e($user->resume); ?>" alt=""
                                            class="text-decoration-none" target="_blank">Resume</a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="text-center">
                            <?php echo e($users->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\mla-new\resources\views/livewire/admin/registered-users.blade.php ENDPATH**/ ?>