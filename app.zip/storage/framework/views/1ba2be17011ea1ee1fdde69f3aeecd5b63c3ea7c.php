<div class="my-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-6">
                                <h3>SV Gallery Add Image</h3>
                            </div>
                            <div class="col-md-6">
                                <div class="text-end">
                                    <a href="<?php echo e(route('admin.svgallery')); ?>" class="btn btn-primary">All Images</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row justify-content-center">
                            <div class="col-md-6">
                                <div class="">
                                    <form enctype="multipart/form-data" wire:submit.prevent='adddata'>
                                        
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="input-group mb-3">
                                                    <span class="input-group-text me-1 bg-primary" id="basic-addon1"><i
                                                            class="fa fa-user text-white"></i></span>
                                                    <input type="text" class="form-control" placeholder="Image Name"
                                                        aria-label="Username" aria-describedby="basic-addon1"
                                                        name="name" wire:model="name">
                                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="input-group mb-3">
                                                    <input type="file" class="form-control" id="inputGroupFile02"
                                                        name="image" wire:model="image">
                                                    <label class="input-group-text ms-1 " for="inputGroupFile02">Upload
                                                        Image</label>
                                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <?php if($image): ?>
                                                <img src="<?php echo e($image->temporaryUrl()); ?>" alt="" width="400"
                                                    class="img-responsive">
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <?php if(Session::has('success')): ?>
                                        <div class="alert alert-success my-2" role="alert"><?php echo e(Session::get('success')); ?>

                                        </div>
                                        <?php endif; ?>
                                        <?php if(Session::has('error')): ?>
                                        <div class="alert alert-danger my-2" role="alert"><?php echo e(Session::get('error')); ?></div>
                                        <?php endif; ?>
                                        <div class="row mt-3">
                                            <div class="col-md-4">
                                                <button type="submit"
                                                    class="btn btn-primary form-control">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\mla-new\resources\views/livewire/admin/s-v-add-gallery.blade.php ENDPATH**/ ?>