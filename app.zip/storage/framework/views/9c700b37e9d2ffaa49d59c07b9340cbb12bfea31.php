<!DOCTYPE html>
<html>

<head>
    <title>Register</title>
</head>

<body>

    <table rules="all" style="border-style: solid; border-color: #666;" cellpadding="10">
        
        <tbody>
            <tr>
                <th>Name</th>
                <td><?php echo e($data['name']); ?></td>
            </tr>
            <tr>
                <th>Eamil</th>
                <td><?php echo e($data['email']); ?></td>
            </tr>
            <tr>
                <th>Contact</th>
                <td><?php echo e($data['contact']); ?></td>
            </tr>
            <tr>
                <th>Mandal</th>
                <td><?php echo e($data['mandal']); ?></td>
            </tr>
            <tr>
                <th>Village</th>
                <td><?php echo e($data['village']); ?></td>
            </tr>
            <tr>
                <th>Address</th>
                <td><?php echo e($data['address']); ?></td>
            </tr>
            <tr>
                <th>sscpass</th>
                <td><?php echo e($data['sscpass']); ?></td>
            </tr>
            <tr>
                <th>sscpercentage</th>
                <td><?php echo e($data['sscpercentage']); ?></td>
            </tr>
            <tr>
                <th>interpass</th>
                <td><?php echo e($data['interpass']); ?></td>
            </tr>
            <tr>
                <th>interpercentage</th>
                <td><?php echo e($data['interpercentage']); ?></td>
            </tr>
            <tr>
                <th>qualification</th>
                <td><?php echo e($data['qualification']); ?></td>
            </tr>
            <tr>
                <th>graduationstream</th>
                <td><?php echo e($data['graduationstream']); ?></td>
            </tr>
            <tr>
                <th>graduationpass</th>
                <td><?php echo e($data['graduationpass']); ?></td>
            </tr>
            <tr>
                <th>graduationpercentage</th>
                <td><?php echo e($data['graduationpercentage']); ?></td>
            </tr>
            <tr>
                <th>resume</th>
                <td><a href="<?php echo e(asset('assets/images/resumes')); ?>/<?php echo e($data['imagename']); ?>" alt=""
                    class="text-decoration-none" target="_blank">Resume</a></td>
            </tr>
        </tbody>
    </table>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\mla-new\resources\views/email/registermail.blade.php ENDPATH**/ ?>