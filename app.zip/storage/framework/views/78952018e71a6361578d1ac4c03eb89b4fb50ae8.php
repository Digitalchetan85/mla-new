<div>
    Admin Dashboard
</div>
<?php /**PATH C:\xampp\htdocs\mla-new\resources\views/livewire/admin/admin-dashboard-component.blade.php ENDPATH**/ ?>